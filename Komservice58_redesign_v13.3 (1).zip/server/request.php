<?php
// Server-side draft. Deploy only after operator approval, local privacy review and integration testing.
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
function respond(int $code, string $message): void { http_response_code($code); echo json_encode(['message'=>$message], JSON_UNESCAPED_UNICODE); exit; }
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') respond(405,'Только POST');
if (($_SERVER['HTTP_ORIGIN'] ?? '') !== 'https://komservice58.ru') respond(403,'Запрос отклонён');
if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0)>8192) respond(413,'Слишком большой запрос');
if (getenv('KS_LIVE_ENABLED') !== '1') respond(503,'Приём заявок пока не подключён');
$token=getenv('KS_MAX_TOKEN'); $id=getenv('KS_MAX_USER_ID');
if (!$token || !$id || !preg_match('/^\d+$/',$id)) respond(503,'Приём заявок пока не подключён');
$data=json_decode(file_get_contents('php://input',false,null,0,8192),true);
if (!is_array($data) || ($data['consent']??false)!==true) respond(400,'Требуется согласие');
$allowed=['Прочистка канализации','Устранение засоров','Гидродинамическая прочистка канализации','Услуги илососа','Услуги ассенизатора','Обслуживание систем канализации','Телеинспекция и видеодиагностика','Аренда и обслуживание биотуалетов'];
foreach(['name','phone','service','comment'] as $key) if(!is_string($data[$key]??null)) respond(400,'Проверьте поля');
$name=trim($data['name']); $phone=trim($data['phone']); $comment=trim($data['comment']); $service=$data['service'];
if ($name==='' || mb_strlen($name)>100 || !preg_match('/^[+0-9()\s-]{10,20}$/D',$phone) || mb_strlen($comment)>1000 || !in_array($service,$allowed,true)) respond(400,'Проверьте поля');
// Require web-server rate limiting / bot protection before enabling.
$text="Новая заявка — КОМСЕРВИС\nСайт: komservice58.ru\nУслуга: $service\nИмя: $name\nТелефон: $phone\nКомментарий: $comment\nСогласие: подтверждено";
$ch=curl_init('https://platform-api2.max.ru/messages?user_id='.rawurlencode($id));
curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_HTTPHEADER=>['Authorization: '.$token,'Content-Type: application/json'],CURLOPT_POSTFIELDS=>json_encode(['text'=>$text],JSON_UNESCAPED_UNICODE),CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>12,CURLOPT_CONNECTTIMEOUT=>5]);
$result=curl_exec($ch);$status=curl_getinfo($ch,CURLINFO_RESPONSE_CODE);curl_close($ch);
if($result===false || $status<200 || $status>=300) respond(502,'Не удалось отправить заявку. Позвоните нам.');
respond(200,'Заявка отправлена');
